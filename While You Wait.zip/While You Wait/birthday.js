var daysUntilMyBirthday = 60;
while(daysUntilMyBirthday > 30){
    console.log(daysUntilMyBirthday);
    console.log("So far away ... :/");
    daysUntilMyBirthday -= 1;
}

while(daysUntilMyBirthday > 5){
    console.log(daysUntilMyBirthday);
    console.log("Getting closer!!!");
    daysUntilMyBirthday -= 1;
}

while(daysUntilMyBirthday > 0){
    console.log(daysUntilMyBirthday);
    console.log("HOLY $#@% SO CLOSE");
    daysUntilMyBirthday -= 1;
}

while(daysUntilMyBirthday >= 0){
    console.log(daysUntilMyBirthday);
    console.log("HAPPY BIRTHDAY TO MEEEEEEEEEE!");
    break;
}

