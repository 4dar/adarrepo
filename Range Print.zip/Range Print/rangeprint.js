function printRange(startPoint, endPoint, skipAmount){
    for(var i = startPoint; i < endPoint; i += skipAmount){
        console.log(i);
    }
}
printRange(2, 10, 2);

function printRange(startPoint, endPoint, skipAmount){
    for(var i = startPoint; i < endPoint; i += skipAmount){
        console.log(i);
    }
}

function printRange(startPoint, endPoint, skipAmount){
    for(var i = endPoint; i < startPoint; i+= skipAmount){
        console.log(i);
    }
        if(startPoint > endPoint){
        console.log(i);
    }
}
printRange(20, -10, 2);
    
function printRange(startPoint, endPoint){
    for(var i = startPoint; i < endPoint; i ++){
        console.log(i);
    }
}
printRange(4, 8);

function printRange(startPoint){
    for(var i = 0; i < startPoint; i ++){
        console.log(i);
    }
}
printRange(4);