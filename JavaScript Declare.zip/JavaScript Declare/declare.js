var numb1 = 5;
var numb2 = 4.4;
var numb3 = -23;
var numb4 = 184;
console.log("four numbers", numb1, numb2, numb3, numb4);

var string1 = 'yo';
var string2 = 'codingisamazing';
var string3 = 'mom?';
console.log("these are my strings", string1, string2, string3);

var bool1 = true;
var bool2 = false;
console.log("true or false?", bool1, bool2);